# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers
# Edit for Eureka R7.5 by Eureka Team on XDA
## AnyKernel setup
# begin properties
properties() { '
kernel.string=
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=
device.name2=
device.name3=
device.name4=
device.name5=
supported.versions=
'; } # end properties

# shell variables
is_slot_device=0
ramdisk_compression=auto

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh

## AnyKernel file attributes

# Change permissions
chmod 755 /system/bin/busybox

## AnyKernel install
umount_all() {
	umount /system
	umount /system_root
}

mount_androidroot() {
	export TMPSYSROOT=$ANDROID_ROOT
	mount $ANDROID_ROOT
}

mount_system() {
	export TMPSYSROOT=/system
	mount /system
}

mount_systemroot() {
	export TMPSYSROOT=/system_root
	mount /system_root
}

umount_all

mount_systemroot || mount_system || mount_androidroot
mount /vendor

# Remount system as read-write
mount -o rw,remount -t auto $TMPSYSROOT
mount -o rw,remount -t auto /vendor

# Locate init path
INIT_PATH=$TMPSYSROOT/system/etc/init
INIT_PATH2=/vendor/etc/init

if [ -d "$INIT_PATH" ]; then
	INIT=$INIT_PATH
elif [ -d "$INIT_PATH2" ]; then
	INIT=$INIT_PATH2
else
	ui_print "!- Cannot find init folder, make sure system is not empty."
	exit 1
fi

## Enable Spectrum Support
ui_print " "
ui_print "- Configuring Spectrum support"
ui_print " "

# Remove old spectrum
if [ -e "$INIT/init.spectrum.rc" ]; then
	rm -f $INIT/init.spectrum.rc
	rm -f $INIT/init.spectrum.sh
fi

if [ -e "$TMPSYSROOT/init.spectrum.rc" ]; then
	rm -f $TMPSYSROOT/init.spectrum.rc
	rm -f $TMPSYSROOT/init.spectrum.sh
fi

cp -f /tmp/anykernel/tools/init.spectrum.rc $INIT/
chmod 644 $INIT/init.spectrum.rc
cp -f /tmp/anykernel/tools/init.spectrum.sh $INIT/
chmod 755 $INIT/init.spectrum.sh

umount $TMPSYSROOT || umount_all

## end install
