# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers
# Edit for Eureka R6.1 by @chatur27 on XDA
## AnyKernel setup
# begin properties
properties() { '
kernel.string=
do.devicecheck=0
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=
device.name2=
device.name3=
device.name4=
device.name5=
supported.versions=
'; } # end properties

# shell variables
is_slot_device=0;
ramdisk_compression=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;


## AnyKernel file attributes

# Change permissions
chmod 755 /system/bin/busybox;

## AnyKernel install

mount /system/
mount /system_root/
mount -o rw,remount -t auto /system >/dev/null;
mount -o rw,remount /vendor;

## Enable Spectrum Support
ui_print " ";
ui_print "- Configuring Spectrum support";
ui_print " ";
cp /tmp/anykernel/tools/init.spectrum.rc /system_root/init.spectrum.rc;
chmod 644 /system_root/init.spectrum.rc;
cp /tmp/anykernel/tools/init.spectrum.sh /system_root/init.spectrum.sh;
chmod 755 /system_root/init.spectrum.sh;

insert_line /system_root/init.rc "import /init.spectrum.rc" after "import /prism/etc/init/init.rc" "import /init.spectrum.rc";
insert_line /system_root/system/etc/init/hw/init.rc "import /init.spectrum.rc" after "import /prism/etc/init/init.rc" "import /init.spectrum.rc";
umount /system;
umount /system_root;

## end install
